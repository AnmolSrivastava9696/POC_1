package TESTNG_TESTS;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import EXCEL_IO.excel_operations;
import EXCEL_IO.test_data;
import REUSABLE_AUT_CLASSES.aut_features;
public class test_class_1 {
  WebDriver driver;
  aut_features template;
   Logger log;
  int i=1;
  
  @BeforeMethod
  public void launchBrowser() 
  {
	     System.setProperty("webdriver.chrome.driver","C:\\Users\\anmol.srivastava\\Desktop\\chromedriver.exe");
	     
	     driver=new ChromeDriver();
	   
		driver.get("http://automationpractice.com/index.php");
		driver.findElement(By.xpath("//a[@class='login']")).click();
		log= Logger.getLogger("devpinoyLogger"); 
		// driver.manage().window().maximize();
		//driver.manage().timeouts().implicitlyWait(3000,TimeUnit.MILLISECONDS);
  }
  @Test(dataProvider="stringExpectedResults")
  public void verifyRegistration(String expectedResult) throws InterruptedException 
  {
	  
	 
	  template=new aut_features(driver);
	  test_data td=excel_operations.readExcel(i);
	  template.createAccount(td);
	 
	  String actualResult=template.getActualResult();
	  excel_operations.writeActualResult(actualResult,i);
	  //Assert.assertEquals(actualResult,expectedResult);
	  SoftAssert sa=new SoftAssert();
	  sa.assertEquals(actualResult,expectedResult);
	  String test_result=template.evaluateTestResult(actualResult, expectedResult);
	  excel_operations.writeTestResult(test_result,i);
	 
	  
	 
	  log.debug("verify registration for "+td.getTc_id()+" done.Expected:"+expectedResult+" Actual:"+actualResult+" Test Result"+test_result);
      i=i+1;
	  
  }
  @DataProvider(name="stringExpectedResults")
  public String[] getExpectedResultsString() 
  {
	  
	  String[] expectedResultsString=new String[3];
	  for(int i=1;i<4;i++) 
	  {
		 test_data td=excel_operations.readExcel(i);
		String expected_result= td.getExpected_result();
		
		expectedResultsString[i-1]=expected_result;
		  
	  }
	  return expectedResultsString;
	  
	  
	  
  }
  @AfterMethod
  public void afterTest() 
  {
	 driver.close();
  }
}
