package REUSABLE_AUT_CLASSES;
//This class contains the basic operations which are to be performed while registering a user into the site 
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import EXCEL_IO.excel_operations;
import EXCEL_IO.test_data;

public class aut_features 
{
	WebDriver driver;

public aut_features(WebDriver driver2) 
    {
           driver=driver2;
	}
 //this method passes all the test data member variables into the respective fields of registration page
public void createAccount(test_data td) throws InterruptedException 
{
	


driver.findElement(By.xpath("//input[@id='email_create']")).sendKeys(td.getEmail());
driver.findElement(By.xpath("//button[@id='SubmitCreate']")).click();
Wait wait=new WebDriverWait(driver,20); 
wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='customer_firstname']")));
driver.findElement(By.xpath("//input[@name='customer_firstname']")).sendKeys(td.getFirst_name());
driver.findElement(By.xpath("//input[@name='customer_lastname']")).sendKeys(td.getLast_name());
driver.findElement(By.xpath("//input[@name='passwd']")).sendKeys(td.getPassword());
driver.findElement(By.xpath("//input[@name='firstname']")).sendKeys(td.getFirst_name());
driver.findElement(By.xpath("//input[@name='lastname']")).sendKeys(td.getLast_name());
driver.findElement(By.xpath("//input[@name='address1']")).sendKeys(td.getAddress());
driver.findElement(By.xpath("//input[@name='city']")).sendKeys(td.getCity());
WebElement state=driver.findElement(By.xpath("//*[@id='id_state']"));
Select sel=new Select(state);
sel.selectByVisibleText(td.getState());
driver.findElement(By.xpath("//input[@name='postcode']")).sendKeys(td.getPostal_code());
driver.findElement(By.xpath("//input[@name='phone_mobile']")).sendKeys(td.getMobile_no());
driver.findElement(By.xpath("//input[@name='alias']")).clear();
driver.findElement(By.xpath("//input[@name='alias']")).sendKeys(td.getAddress_alias());
driver.findElement(By.xpath("//button[@name='submitAccount']")).click();

}
//This method fetched the actual result after successful registration 
public String getActualResult() 
{ 
	
	Wait wait=new WebDriverWait(driver,20); 
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@class='account']")));
	WebElement actualResultElement=driver.findElement(By.xpath("//a[@class='account']"));
	
	String actualResult=actualResultElement.getText();
	
	return actualResult;
}
//Methods evaluate a test data as pass or fail by matching expected and actual result
public String evaluateTestResult(String actual,String expected) 
{
	
if(actual.contentEquals(expected)) 
{
	return "Pass";
}
else 
	return "fail";

}

}
